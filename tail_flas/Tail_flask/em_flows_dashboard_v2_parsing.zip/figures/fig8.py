from .common import parse_figure
def parse(pdf_path,cfg): return parse_figure(pdf_path,'FIGURE 8',cfg)
