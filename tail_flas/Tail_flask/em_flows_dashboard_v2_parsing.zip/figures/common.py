from . import helpers
def parse_figure(pdf_path, fig_name, cfg):
    dcfg=cfg["digitizer"]; crops=dcfg["crops"].get(fig_name); yr=dcfg["y_ranges"].get(fig_name); dpi=int(dcfg.get("dpi",220))
    fig_cfg=dcfg["figures"].get(fig_name,{}); hsv_presets=dcfg.get("hsv_thresholds",{})
    if not crops or not yr or not fig_cfg: return []
    img=helpers.render_pdf_page(pdf_path, int(crops.get("page",0)), dpi=dpi)
    plot=helpers.relative_crop(img, crops["left"], crops["top"], crops["right"], crops["bottom"])
    mode=fig_cfg.get("mode","bars").lower(); series_defs=fig_cfg.get("series",[])
    y_min=float(yr["y_min"]); y_max=float(yr["y_max"]); vals={}
    for sd in series_defs:
        name=sd["name"]; hsv=hsv_presets[sd["hsv"]]
        seq=helpers.extract_bars(plot,hsv,y_min,y_max) if mode.startswith("bar") else helpers.extract_line(plot,hsv,y_min,y_max)
        latest=next((v for v in reversed(seq) if v==v), None)
        if latest is not None: vals[name]=latest
    mult=1000.0 if (fig_cfg.get("units") or yr.get("units","")).lower().find("bn")>=0 else 1.0
    rows=[]
    for name,v in vals.items():
        row={"figure":fig_name,"series":name,"asset_class":None,"region":None,"fund_type":None,"value_usd_mn":float(v)*mult}
        ac_map=fig_cfg.get("asset_class_by_series"); reg_map=fig_cfg.get("region_by_series"); ft_map=fig_cfg.get("fund_type_by_series")
        if ac_map and name in ac_map: row["asset_class"]=ac_map[name]
        if reg_map and name in reg_map: row["region"]=reg_map[name]
        if ft_map and name in ft_map: row["fund_type"]=ft_map[name]
        if fig_cfg.get("asset_class"): row["asset_class"]=fig_cfg["asset_class"]
        if fig_cfg.get("region"): row["region"]=fig_cfg["region"]
        if fig_cfg.get("fund_type"): row["fund_type"]=fig_cfg["fund_type"]
        rows.append(row)
    return rows
