from .common import parse_ffigure
def parse(pdf_path,cfg): return parse_figure(pdf_path,'FIGURE 4',cfg)
