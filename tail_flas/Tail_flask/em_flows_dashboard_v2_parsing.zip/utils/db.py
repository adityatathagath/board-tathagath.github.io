import os, pandas as pd, numpy as np
SCHEMA_COLS = ["date","figure","asset_class","region","fund_type","series","value_usd_mn","source_pdf"]
def _empty_df(): return pd.DataFrame(columns=SCHEMA_COLS)
def append_records(records, db_path="flows_db.parquet"):
    if not records: return 0
    df_new = pd.DataFrame(records)[SCHEMA_COLS]
    df_new["date"] = pd.to_datetime(df_new["date"])
    df_new["value_usd_mn"] = pd.to_numeric(df_new["value_usd_mn"], errors="coerce")
    if os.path.exists(db_path): df = pd.read_parquet(db_path); df_all = pd.concat([df, df_new], ignore_index=True)
    else: df_all = df_new.copy()
    df_all = df_all.drop_duplicates(subset=["date","figure","series"], keep="last")
    df_all.to_parquet(db_path, index=False); return len(df_new)
def load_db(db_path="flows_db.parquet"):
    if os.path.exists(db_path): return pd.read_parquet(db_path)
    return _empty_df()
