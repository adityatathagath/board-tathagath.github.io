import io, pandas as pd
def weekly_note(d):
    if d.empty: return "# EM Flows Weekly – (no data yet)\n"
    latest=d["date"].max(); cur=d[d["date"]==latest].sort_values("value_usd_mn")
    top_out=cur.head(5); top_in=cur.tail(5)
    s=io.StringIO(); s.write(f"# EM Flows Weekly – {latest.date()}\n\n## Highlights\n")
    if len(top_in):
        s.write("**Strongest Inflows:**\n")
        for _,r in top_in.iterrows(): s.write(f"- {r.get('region') or 'Global'} / {r.get('asset_class')} / {r.get('series')}: {r.get('value_usd_mn'):.0f} mn\n")
    if len(top_out):
        s.write("\n**Strongest Outflows:**\n")
        for _,r in top_out.iterrows(): s.write(f"- {r.get('region') or 'Global'} / {r.get('asset_class')} / {r.get('series')}: {r.get('value_usd_mn'):.0f} mn\n")
    return s.getvalue()
