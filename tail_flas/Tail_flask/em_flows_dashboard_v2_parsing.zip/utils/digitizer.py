import numpy as np, cv2, fitz, pdfplumber, re
from PIL import Image
from dateutil import parser as dateparser

def render_pdf_page(pdf_path: str, page_index: int, dpi: int = 220):
    doc = fitz.open(pdf_path)
    page = doc.load_page(page_index)
    mat = fitz.Matrix(dpi/72, dpi/72)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    return img

def relative_crop(img: Image.Image, left: float, top: float, right: float, bottom: float) -> Image.Image:
    w, h = img.size
    box = (int(left*w), int(top*h), int(right*w), int(bottom*h))
    return img.crop(box)

def to_cv(img: Image.Image):
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def mask_hsv(img_bgr, hsv):
    hsv_img = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    lower = np.array([hsv["h_min"], hsv["s_min"], hsv["v_min"]], dtype=np.uint8)
    upper = np.array([hsv["h_max"], hsv["s_max"], hsv["v_max"]], dtype=np.uint8)
    return cv2.inRange(hsv_img, lower, upper)

def detect_baseline_y(plot_bgr):
    gray = cv2.cvtColor(plot_bgr, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=120, minLineLength=int(plot_bgr.shape[1]*0.5), maxLineGap=10)
    y_candidates = []
    if lines is not None:
        for x1,y1,x2,y2 in lines[:,0]:
            if abs(y1-y2) <= 2: y_candidates.append(y1)
    if not y_candidates: return plot_bgr.shape[0]//2
    mid = plot_bgr.shape[0]//2
    return min(y_candidates, key=lambda yy: abs(yy-mid))

def estimate_px_per_unit(plot_bgr, y_min, y_max, baseline_y):
    h = plot_bgr.shape[0]
    pos_span_px = baseline_y - 0
    neg_span_px = h - baseline_y
    pos_units = max(0.0001, y_max if y_max>0 else 0.0001)
    neg_units = abs(y_min) if y_min<0 else 0.0001
    px_per_unit_pos = pos_span_px / pos_units
    px_per_unit_neg = neg_span_px / neg_units
    if y_min < 0 and y_max > 0:
        return (px_per_unit_pos + px_per_unit_neg) / 2.0
    return px_per_unit_pos

def extract_bars(plot_img: Image.Image, hsv_thresh: dict, y_min: float, y_max: float):
    bgr = to_cv(plot_img)
    baseline_y = detect_baseline_y(bgr)
    mask = mask_hsv(bgr, hsv_thresh)
    mask = cv2.medianBlur(mask, 5)
    cols = mask.shape[1]
    col_sum = (mask>0).sum(axis=0).astype(np.float32)
    kernel = np.ones(5, dtype=np.float32)/5.0
    smooth = np.convolve(col_sum, kernel, mode="same")
    thr = max(1.0, np.percentile(smooth, 75) * 0.3)
    is_bar = smooth > thr
    bars = []
    in_seg = False; start = 0
    for i, val in enumerate(is_bar):
        if val and not in_seg: in_seg=True; start=i
        elif not val and in_seg: in_seg=False; bars.append((start, i-1))
    if in_seg: bars.append((start, cols-1))
    heights = []
    for (x1,x2) in bars:
        seg = mask[:, x1:x2+1]
        ys = np.where(seg>0)[0]
        if ys.size == 0: heights.append(np.nan); continue
        y_top = ys.min(); y_bot = ys.max()
        pos = max(0, baseline_y - y_top)
        neg = max(0, y_bot - baseline_y)
        net = float(pos - neg)
        heights.append(net)
    px_per_unit = estimate_px_per_unit(bgr, y_min, y_max, baseline_y)
    values = [h/px_per_unit if h==h else np.nan for h in heights]
    return values

def extract_line(plot_img: Image.Image, hsv_thresh: dict, y_min: float, y_max: float):
    bgr = to_cv(plot_img)
    mask = mask_hsv(bgr, hsv_thresh)
    kernel = np.ones((3,3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    h,w = mask.shape
    ys = []
    for x in range(w):
        col = np.where(mask[:,x]>0)[0]
        ys.append(float(np.median(col)) if col.size>0 else np.nan)
    baseline_y = detect_baseline_y(bgr)
    px_per_unit = estimate_px_per_unit(bgr, y_min, y_max, baseline_y)
    vals = []
    for y in ys:
        if y==y:
            diff = baseline_y - y
            vals.append(diff/px_per_unit)
        else:
            vals.append(np.nan)
    return vals

def parse_report_date(pdf_path: str, date_patterns):
    try:
        with pdfplumber.open(pdf_path) as pdf:
            pages_to_try = min(3, len(pdf.pages))
            import re
            for i in range(pages_to_try):
                t = pdf.pages[i].extract_text() or ""
                for pat in date_patterns:
                    for m in re.finditer(pat, t):
                        groups = [g for g in m.groups() if g]
                        if not groups: continue
                        candidate = groups[-1]
                        try:
                            dt = dateparser.parse(candidate, dayfirst=False, fuzzy=True)
                            return dt.date().isoformat()
                        except Exception: pass
    except Exception: pass
    import os, re
    fname = os.path.basename(pdf_path)
    pats = [r"([0-9]{4}[-_][0-9]{2}[-_][0-9]{2})", r"([0-9]{8})", r"([0-9]{1,2}[A-Za-z]{3,9}[0-9]{2,4})"]
    for p in pats:
        m = re.search(p, fname)
        if m:
            try:
                dt = dateparser.parse(m.group(1), dayfirst=True, fuzzy=True)
                return dt.date().isoformat()
            except Exception: pass
    from datetime import date as _d
    return _d.today().isoformat()
