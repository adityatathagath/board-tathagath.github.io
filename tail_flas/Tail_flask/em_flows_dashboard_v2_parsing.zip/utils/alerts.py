import pandas as pd, numpy as np
def prep(df): d=df.copy(); d["date"]=pd.to_datetime(d["date"]); return d
def compute_rolls(df, group_cols=["asset_class","region","fund_type","series"]):
    d=prep(df).sort_values("date")
    d["roll_4w"]=d.groupby(group_cols)["value_usd_mn"].transform(lambda s:s.rolling(4,min_periods=2).sum())
    d["roll_12w"]=d.groupby(group_cols)["value_usd_mn"].transform(lambda s:s.rolling(12,min_periods=3).sum())
    d["roll_52w"]=d.groupby(group_cols)["value_usd_mn"].transform(lambda s:s.rolling(52,min_periods=8).sum())
    def rz(s,w=52): 
        mu=s.rolling(w,min_periods=8).mean(); sd=s.rolling(w,min_periods=8).std(ddof=0); 
        return (s-mu)/sd.replace(0,np.nan)
    d["z_52w"]=d.groupby(group_cols)["value_usd_mn"].transform(rz)
    return d
def alerts_latest(d, top_n=10):
    if d.empty: return []
    latest=d["date"].max(); cur=d[d["date"]==latest].dropna(subset=["z_52w"])
    if cur.empty: return []
    outs=cur.sort_values("z_52w").head(top_n).to_dict("records")
    ins =cur.sort_values("z_52w").tail(top_n).to_dict("records")
    out=[]; 
    for r in ins: out.append({"type":"Extreme Inflow","where":f'{r.get("region") or "Global"} / {r.get("asset_class")} / {r.get("series")}',"detail":f'z={r.get("z_52w"):.2f}, WoW={r.get("value_usd_mn"):.0f} mn, 4W={r.get("roll_4w",float("nan")):.0f}',"date":str(latest.date())})
    for r in outs: out.append({"type":"Extreme Outflow","where":f'{r.get("region") or "Global"} / {r.get("asset_class")} / {r.get("series")}',"detail":f'z={r.get("z_52w"):.2f}, WoW={r.get("value_usd_mn"):.0f} mn, 4W={r.get("roll_4w",float("nan")):.0f}',"date":str(latest.date())})
    return out
