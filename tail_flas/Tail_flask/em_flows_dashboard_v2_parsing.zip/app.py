import os, yaml, pandas as pd, streamlit as st, plotly.express as px
from utils.digitizer import parse_report_date
from utils.db import append_records, load_db
from utils.alerts import compute_rolls, alerts_latest
from utils.notes import weekly_note
from figures import fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9
FIG_PARSERS={'FIGURE 1':fig1,'FIGURE 2':fig2,'FIGURE 3':fig3,'FIGURE 4':fig4,'FIGURE 5':fig5,'FIGURE 6':fig6,'FIGURE 7':fig7,'FIGURE 8':fig8,'FIGURE 9':fig9}
st.set_page_config(page_title='EM Flows v2 (Auto-Parsing)', layout='wide')
st.title('EM Flows – v2 (Auto-Parsing)')
with open('config.yml','r') as f: CFG=yaml.safe_load(f)
with st.sidebar:
    st.header('Upload Weekly PDFs'); files=st.file_uploader('Drop PDFs here', type=['pdf'], accept_multiple_files=True)
    if st.button('Ingest', disabled=not files):
        total=0
        for fobj in files:
            os.makedirs('data', exist_ok=True); path=os.path.join('data', fobj.name)
            with open(path,'wb') as w: w.write(fobj.read())
            as_of=parse_report_date(path, CFG.get('date_patterns', []))
            all_rows=[]
            for fname,mod in FIG_PARSERS.items():
                rows=mod.parse(path, CFG)
                for r in rows: r['date']=as_of; r['source_pdf']=os.path.basename(path)
                all_rows.extend(rows)
            total+=append_records(all_rows, db_path='flows_db.parquet')
        st.success(f'Ingested {len(files)} PDF(s). New rows: {total}')
db=load_db('flows_db.parquet')
if db.empty: st.info('No data yet. Upload PDFs and click Ingest.'); st.stop()
st.write('**Latest date in DB:**', db['date'].max()); st.write('Rows:', len(db))
st.dataframe(db.sort_values(['date','figure','series']).tail(50), use_container_width=True)
tabs=st.tabs(['Global Overview','Bond Flows','Equity Flows','Regional Spotlight','Analytics & Alerts','Weekly Note'])
with tabs[0]:
    latest=db['date'].max()
    snap=db[(db['date']==latest) & ((db['region'].isna()) | (db['region']=='Global'))]
    if not snap.empty:
        fig=px.bar(snap, x='asset_class', y='value_usd_mn', color='series', title=f'Latest week: {latest.date()} (USD mn)')
        st.plotly_chart(fig, use_container_width=True)
with tabs[1]:
    d=db[db['asset_class'].str.contains('Bond', na=False)]
    if not d.empty:
        fig=px.line(d.sort_values('date'), x='date', y='value_usd_mn', color='series'); st.plotly_chart(fig, use_container_width=True)
with tabs[2]:
    d=db[(db['asset_class']=='Equity') & (db['region'].notna())]
    if not d.empty:
        fig=px.line(d.sort_values('date'), x='date', y='value_usd_mn', color='region'); st.plotly_chart(fig, use_container_width=True)
with tabs[3]:
    d=db[db['region'].notna()]
    if not d.empty:
        fig=px.line(d.sort_values('date'), x='date', y='value_usd_mn', color='region', facet_col='asset_class', facet_col_wrap=2)
        st.plotly_chart(fig, use_container_width=True)
with tabs[4]:
    rolls=compute_rolls(db); st.dataframe(pd.DataFrame(alerts_latest(rolls)), use_container_width=True)
with tabs[5]:
    rolls=compute_rolls(db); st.code(weekly_note(rolls), language='markdown')
