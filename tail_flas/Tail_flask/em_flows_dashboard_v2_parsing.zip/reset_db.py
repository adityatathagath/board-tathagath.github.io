import os
p='flows_db.parquet'
print('Deleting',p) if os.path.exists(p) and not os.remove(p) else print('No DB file found.')
